//
//  ViewController.swift
//  iOSUI_HW_1
//
//  Created by Philipp Lazarev on 01.05.2023.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

